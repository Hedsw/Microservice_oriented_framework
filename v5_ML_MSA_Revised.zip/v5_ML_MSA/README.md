# microservice_ml

TO RUN CODES.. API DESCRIPTION:

Strategy - RandomForest
 http://0.0.0.0:5000/api/strategy/randomforest

Strategy - SVM
 http://0.0.0.0:5000/api/strategy/svm

File Upload 
 http://0.0.0.0:5009/uploader

RandomForest 
 http://0.0.0.0:5002/api/randomforest

SVM
 http://0.0.0.0:5003/api/svm

Preprocess - Logistic regression
 http://0.0.0.0:5001/api/preprocess/preprocess2
 
Preprocess - lasso regression
 http://0.0.0.0:5001/api/preprocess/preprocess1
 
Evaluation - Data Vis 
 http://0.0.0.0:5005/api/evaluation